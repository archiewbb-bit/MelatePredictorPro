MELATE PREDICTOR PRO - proyecto inicial Android

IMPORTANTE
Este ZIP contiene el código fuente de un proyecto Android Studio, NO un APK ya compilado.
No se ha podido compilar ni probar un APK en este entorno.

REQUISITOS
- Android Studio actualizado
- JDK 17 o superior
- Android SDK Platform 35

CÓMO GENERAR EL APK
1. Descomprime el ZIP en una computadora.
2. Abre Android Studio y elige Open.
3. Selecciona la carpeta MelatePredictorPro.
4. Espera a que Gradle sincronice y descargue los componentes.
5. Menú Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio mostrará la ubicación del APK generado.

FUNCIONES INCLUIDAS EN ESTA VERSIÓN INICIAL
- Captura manual de sorteos.
- Historial local en el teléfono.
- Importación/exportación JSON.
- Frecuencias históricas.
- Generación de combinaciones aleatorias y basadas en frecuencia.
- Interfaz en español.

PENDIENTE
- Conectar una fuente oficial/verificable de resultados para actualización automática.
- Implementar y validar modelos Markov, Bayesiano, Monte Carlo y análisis Fibonacci.
- Probar la app en distintos teléfonos Android.

Los modelos estadísticos no pueden predecir ni garantizar un resultado de lotería.
